from flask import Flask, render_template, request, jsonify
from telnetlib import Telnet
import time
import re
from werkzeug.debug import console
import argparse

parser = argparse.ArgumentParser(description='Run the Flask app with specified port.')
parser.add_argument('--port', type=int, default=50000, help='The port to run the Flask app on.')
args = parser.parse_args()
app = Flask(__name__)

# host = "10.136.70.10"

host = "127.0.0.1"
port = args.port
tn = Telnet(host, port)

welstr = "********************************************************************\
You are attempting to log into online tic-tac-toe Server.\
Please be advised by continuing that you agree to the terms of the\
Computer Access and Usage Policy of online tic-tac-toe Server.\
\
********************************************************************\
\
\
username(guest):"

output = welstr
player_info = ""
board_data = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]

def remove_bracket_content(s):
    return re.sub(r'<.*?>', '', s)

def telnet_connection(command):
    tn.write((command + '\n\n').encode('utf-8'))
    time.sleep(0.5)

@app.route('/')
def index():
    return render_template('index.html', player_info=player_info)

def check_board(str):
    count = 0
    for line in str.strip().split('\n'):
        if line[:7] == "  1 2 3":
            return count
        count += 1
    return 0


def parse_board(board_str, count):
    global board_data
    lines = board_str.strip().split('\n')
    board_info = lines[count + 1:count + 4]
    for i in range(3):
        words = board_info[i].split(" ")
        for j in range(3):
            word = words[j + 1]
            if word == "X":
                board_data[i][j] = 1
            elif word == "O":
                board_data[i][j] = 2
            else:
                board_data[i][j] = 0
    outstr = lines[count-2] + "\n" + lines[count-1]
    for line in lines:
        if "win" in line or "lose" in line or "draw" in line:
            line1 = remove_bracket_content(line)
            outstr += "\n"+line1
    return outstr


@app.route('/get_output')
def get_output():
    global output, board_data, player_info
    temp_telnet_player_info = tn.read_very_eager().decode('utf8')
    if temp_telnet_player_info != "":
        count = check_board(temp_telnet_player_info)
        output = temp_telnet_player_info
        if count > 0:
            print("Found board data")
            player_info = parse_board(temp_telnet_player_info, count)\

    return jsonify({'output': output, 'board_data': board_data, 'player_info': player_info})


@app.route('/make_move', methods=['POST'])
def make_move():
    data = request.json
    move = data['move']
    print("Received move:", move)
    telnet_connection(move)
    return jsonify({'status': 'success', 'move': move})


@app.route('/submit', methods=['POST'])
def submit():
    global player_info, output, board_data
    if request.method == 'POST':
        command = request.form['command']
        telnet_connection(command)
        return render_template('index.html', command=command, output=output, board_data=board_data, player_info=player_info)


if __name__ == '__main__':
    app.run(debug=True, port=7777)
